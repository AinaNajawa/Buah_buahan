 //1. Import class
 import java.util.Scanner; //perpustakaan

import javax.print.DocFlavor.STRING;
public class Jenis_buah{ //nama class
    public static void main (String [] args){

        //2. Declare Pemboleh ubah atau pun yang boleh di ubah 
        Scanner input = new Scanner(System.in);

        //data type  ( verebel/pembolehubah)
       int kuantiti;
        double harga ;
        double jumlah ;

        //ini dia akan pangil balik pemboleh ubah di atas
        //pembolehubah
        harga =10.00;
        kuantiti = 1;
        
        //ini adalah pengiraan jumlah untuk buah2 di atas
        

        //4. output
        System.out.println("JENIS BUAH DAN KG ");
        System.out.println("Oren =kg 3");
        System.out.println("Epal =kg 5");
        System.out.println("Betik =kg 2");


        //metet method ();
        System.out.print("Masukkan jenis buah Pertama: ");
        //input.next ini boleh keyin input
        input.next();
        System.out.print("Masukkan jenis buah Kedua: ");
        input.next();
        System.out.print("Masukkan jenis buah Ketiga: ");
        input.next();
        
        //di atas dah ada sener input pembuka input.close
        //kalau tak letak input.close

        System.out.println("Masukkan kg: ");
        int Oren = input.nextInt();
        System.out.println("Masukkan kg buah kedua: ");
        int Epal = input.nextInt();
        System.out.println("Masukkan kg buah Ketiga: ");
        int betik = input.nextInt();
        //method untuk tutup
        input.close();

        //operasi
        int jenis_buah = Oren + Epal + betik;
        kuantiti = jenis_buah;
        jumlah = kuantiti*harga;

        //output
        System.out.println("Harga Setiap 1 Kilo Ialah :" + harga);
        System.out.println("Kuantiti Buah Keseluruhan Yang Dibeli: " + kuantiti);
        System.out.println("Jumlah  Bayaran Untuk Kesemua Buah: Rm" + jumlah);
    }
}